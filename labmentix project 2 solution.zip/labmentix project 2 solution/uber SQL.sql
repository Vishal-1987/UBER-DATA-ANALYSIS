select * from uber;        # give full table
describe uber;             # it tells the data type of all columns present in dataset

# 1: Total Number of Requests
select count(`Request id`) as 'total_request_id' from uber;

# 2: Trip Completion Rate
select
round(count(case 
when status='Trip Completed' then 1 end)/ count(*),2) as Completion_rate from uber;

# 3: Number of Requests by Status
select Status,count(*) as `Total Request` from uber
group by Status;

# 4: Hourly Request Volume
select hour(`Request Time`) as Hourly,count(*) as Request from uber
group by hour(`Request Time`)
order by hour(`Request Time`) desc;

# 5: Requests by Pickup Point and Status
select `Pickup point`,Status,count(*) as Request from uber
group by `Pickup point`,Status
order by `Pickup point`;

# 6: No Cars Available by Hour
select hour(`Request Time`) as hour,count(*) as 'No_Cars_Available' from uber
where Status='No Cars Available'
group by hour(`Request Time`)
order by hour(`Request Time`) desc;

# 7: Average Trip Duration (Minutes)
select avg(minute(`Request Time`)) as Average_trip_duration_in_minute from uber;

# 8: Peak Request Hours by Pickup Point
select `Pickup point`,hour(`Request Time`) as hour,count(*) as Request_Made from uber
group by `Pickup point`,hour(`Request Time`)
order by count(*) desc;

# 9: Most Common Cancellation Hours
select hour(`Request Time`) as cancellation_hour,count(*) as common from uber
where Status='Cancelled'
group by hour(`Request Time`)
order by count(*) desc;

# 10: Cancellation Rate by Pickup Point 
select `Pickup point`,round(count(case when Status='Cancelled' then 1 end)/count(*),2) as Cancellation_Rate from uber 
group by `Pickup point`;